package com.gokboru.browser

import android.content.Context
import android.os.Environment
import org.json.JSONArray
import org.json.JSONObject

/** Ayarlar, favoriler ve geçmiş burada saklanır (SharedPreferences). */
class Prefs(context: Context) {

    class Entry(val title: String, val url: String)

    private val sp = context.applicationContext
        .getSharedPreferences("gokboru", Context.MODE_PRIVATE)

    var adBlock: Boolean
        get() = sp.getBoolean("adblock", true)
        set(value) {
            sp.edit().putBoolean("adblock", value).apply()
        }

    var desktopDefault: Boolean
        get() = sp.getBoolean("desktop_default", false)
        set(value) {
            sp.edit().putBoolean("desktop_default", value).apply()
        }

    var gestures: Boolean
        get() = sp.getBoolean("gestures", true)
        set(value) {
            sp.edit().putBoolean("gestures", value).apply()
        }

    var secureTabs: Boolean
        get() = sp.getBoolean("secure_tabs", true)
        set(value) {
            sp.edit().putBoolean("secure_tabs", value).apply()
        }

    var nightMode: Boolean
        get() = sp.getBoolean("night_mode", false)
        set(value) {
            sp.edit().putBoolean("night_mode", value).apply()
        }

    var blockImages: Boolean
        get() = sp.getBoolean("block_images", false)
        set(value) {
            sp.edit().putBoolean("block_images", value).apply()
        }

    var textZoom: Int
        get() = sp.getInt("text_zoom", 100)
        set(value) {
            sp.edit().putInt("text_zoom", value).apply()
        }

    var downloadAsk: Boolean
        get() = sp.getBoolean("download_ask", false)
        set(value) {
            sp.edit().putBoolean("download_ask", value).apply()
        }

    var downloadFolder: Int
        get() = sp.getInt("download_folder", 0).coerceIn(0, DOWNLOAD_FOLDERS.size - 1)
        set(value) {
            sp.edit().putInt("download_folder", value).apply()
        }

    var searchIndex: Int
        get() = sp.getInt("search_engine", 0).coerceIn(0, ENGINES.size - 1)
        set(value) {
            sp.edit().putInt("search_engine", value).apply()
        }

    fun searchUrl(): String = ENGINES[searchIndex].second

    // --- Favoriler ---------------------------------------------------------------------

    fun favorites(): List<Entry> = readList("favorites")

    fun isFavorite(url: String): Boolean = favorites().any { it.url == url }

    /** Favoriyse çıkarır, değilse ekler. Eklendiyse true döner. */
    fun toggleFavorite(title: String, url: String): Boolean {
        val list = favorites().toMutableList()
        val existing = list.indexOfFirst { it.url == url }
        val added: Boolean
        if (existing >= 0) {
            list.removeAt(existing)
            added = false
        } else {
            list.add(0, Entry(title.ifBlank { url }, url))
            added = true
        }
        writeList("favorites", list)
        return added
    }

    // --- Geçmiş ------------------------------------------------------------------------

    fun history(): List<Entry> = readList("history")

    fun addHistory(title: String, url: String) {
        if (url.isBlank() || url.startsWith("file:") || url.startsWith("about:")) return
        val list = history().toMutableList()
        list.removeAll { it.url == url }
        list.add(0, Entry(title.ifBlank { url }, url))
        while (list.size > MAX_HISTORY) list.removeAt(list.size - 1)
        writeList("history", list)
    }

    fun clearHistory() {
        sp.edit().remove("history").apply()
    }

    // --- Profil ------------------------------------------------------------------------

    var profileName: String
        get() = sp.getString("profile_name", "") ?: ""
        set(value) {
            sp.edit().putString("profile_name", value).apply()
        }

    var profileEmail: String
        get() = sp.getString("profile_email", "") ?: ""
        set(value) {
            sp.edit().putString("profile_email", value).apply()
        }

    // --- Odak Modu ---------------------------------------------------------------------

    var focusUntil: Long
        get() = sp.getLong("focus_until", 0L)
        set(value) {
            sp.edit().putLong("focus_until", value).apply()
        }

    fun focusActive(): Boolean = focusUntil > System.currentTimeMillis()

    fun focusMinutesLeft(): Int {
        val left = (focusUntil - System.currentTimeMillis()) / 60000L
        return (left + 1).toInt().coerceAtLeast(0)
    }

    /** Odak Modu açıkken verilen adres engellenen sitelerden biriyse true döner. */
    fun isFocusBlocked(host: String?): Boolean {
        if (host.isNullOrEmpty() || !focusActive()) return false
        val h = host.lowercase()
        return FOCUS_SITES.any { h == it || h.endsWith(".$it") }
    }

    // --- Hızlı erişim kısayolları -------------------------------------------------------

    fun speedDials(): List<Entry> {
        if (!sp.getBoolean("dial_init", false)) {
            writeList("dials", DEFAULT_DIALS.map { Entry(it.first, it.second) })
            sp.edit().putBoolean("dial_init", true).apply()
        }
        return readList("dials")
    }

    fun addSpeedDial(title: String, url: String) {
        val list = speedDials().toMutableList()
        list.removeAll { it.url == url }
        list.add(Entry(title, url))
        writeList("dials", list)
    }

    fun removeSpeedDial(url: String) {
        val list = speedDials().toMutableList()
        list.removeAll { it.url == url }
        writeList("dials", list)
    }

    // --- Çevrimdışı sayfalar (url alanında dosya yolu tutulur) ---------------------------

    fun offlinePages(): List<Entry> = readList("offline")

    fun addOffline(title: String, path: String) {
        val list = offlinePages().toMutableList()
        list.removeAll { it.url == path }
        list.add(0, Entry(title.ifBlank { path }, path))
        writeList("offline", list)
    }

    fun removeOffline(path: String) {
        val list = offlinePages().toMutableList()
        list.removeAll { it.url == path }
        writeList("offline", list)
    }

    // --- Yardımcılar -------------------------------------------------------------------

    private fun readList(key: String): List<Entry> {
        val raw = sp.getString(key, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            val result = ArrayList<Entry>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                result.add(Entry(obj.optString("t"), obj.optString("u")))
            }
            result
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun writeList(key: String, list: List<Entry>) {
        val array = JSONArray()
        for (entry in list) {
            val obj = JSONObject()
            obj.put("t", entry.title)
            obj.put("u", entry.url)
            array.put(obj)
        }
        sp.edit().putString(key, array.toString()).apply()
    }

    companion object {
        const val MAX_HISTORY = 200

        val TEXT_SIZES = intArrayOf(80, 100, 120, 140, 160, 200)

        val FOCUS_MINUTES = intArrayOf(15, 25, 45, 60, 90)

        val FOCUS_SITES = listOf(
            "instagram.com", "tiktok.com", "facebook.com", "x.com", "twitter.com",
            "youtube.com", "netflix.com", "twitch.tv", "reddit.com", "snapchat.com", "discord.com"
        )

        val DEFAULT_DIALS = listOf(
            "Google" to "https://www.google.com",
            "YouTube" to "https://m.youtube.com",
            "Vikipedi" to "https://tr.wikipedia.org",
            "Instagram" to "https://www.instagram.com",
            "Facebook" to "https://m.facebook.com"
        )

        /** Görünen ad ve Android genel klasör adı. Dosyalar bu klasörün içindeki Gokboru altına inir. */
        val DOWNLOAD_FOLDERS = listOf(
            "İndirilenler" to Environment.DIRECTORY_DOWNLOADS,
            "Belgeler" to Environment.DIRECTORY_DOCUMENTS,
            "Resimler" to Environment.DIRECTORY_PICTURES,
            "Videolar" to Environment.DIRECTORY_MOVIES,
            "Müzik" to Environment.DIRECTORY_MUSIC
        )

        val ENGINES = listOf(
            "Google" to "https://www.google.com/search?q=",
            "DuckDuckGo" to "https://duckduckgo.com/?q=",
            "Bing" to "https://www.bing.com/search?q=",
            "Yandex" to "https://yandex.com.tr/search/?text="
        )
    }
}
