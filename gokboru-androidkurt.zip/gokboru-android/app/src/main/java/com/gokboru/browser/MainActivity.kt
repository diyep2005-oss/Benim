package com.gokboru.browser

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ContentValues
import android.content.Context
import android.content.ActivityNotFoundException
import android.content.Intent
import android.app.Dialog
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.provider.MediaStore
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.speech.RecognizerIntent
import android.view.MotionEvent
import android.view.WindowManager
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.widget.doAfterTextChanged
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog

/** Tek bir sekme: kendi WebView'i ve son bilinen durumu. */
internal class BrowserTab(val webView: WebView, val isPrivate: Boolean = false) {
    var title: String = ""
    var url: String = ""
    var progress: Int = 100
    var loading: Boolean = false
    var favicon: Bitmap? = null
    var thumb: Bitmap? = null
    @Volatile var videoUrl: String? = null
}

class MainActivity : AppCompatActivity() {

    private companion object {
        const val NEWTAB_URL = "file:///android_asset/newtab.html"
        const val DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/124.0.0.0 Safari/537.36"
        const val HOME_SCHEME = "gokboru"
        val VIDEO_EXT = Regex("\\.(mp4|webm|m4v|mov)$", RegexOption.IGNORE_CASE)
    }

    private lateinit var prefs: Prefs
    private val tabs = mutableListOf<BrowserTab>()
    private var current: BrowserTab? = null
    private var desktopMode = false
    private var lastBackPress = 0L
    private var immersive = false

    private lateinit var topBar: View
    private lateinit var bottomBar: View
    private lateinit var addressBar: EditText
    private lateinit var addressIcon: ImageView
    private lateinit var progressBar: ProgressBar
    private lateinit var webContainer: FrameLayout
    private lateinit var fullscreenContainer: FrameLayout
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnReload: ImageButton
    private lateinit var tabCount: TextView

    private var gestureStartX = 0f
    private var gestureStartY = 0f
    private var gestureOnBar = false

    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val mobileUserAgent: String by lazy {
        // "; wv" ifadesini kaldırmak, birçok sitenin tarayıcıyı normal Chrome gibi görmesini sağlar.
        WebSettings.getDefaultUserAgent(this).replace("; wv", "")
    }

    private val fileChooser =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            fileCallback?.onReceiveValue(uris)
            fileCallback = null
        }

    private val voiceLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val spoken = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!spoken.isNullOrBlank()) loadFromInput(spoken)
        }

    // ---------------------------------------------------------------------------------------
    // Yaşam döngüsü
    // ---------------------------------------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)
        desktopMode = prefs.desktopDefault

        topBar = findViewById(R.id.topBar)
        bottomBar = findViewById(R.id.bottomBar)
        addressBar = findViewById(R.id.addressBar)
        addressIcon = findViewById(R.id.addressIcon)
        progressBar = findViewById(R.id.progressBar)
        webContainer = findViewById(R.id.webContainer)
        fullscreenContainer = findViewById(R.id.fullscreenContainer)
        btnBack = findViewById(R.id.btnBack)
        btnForward = findViewById(R.id.btnForward)
        btnReload = findViewById(R.id.btnReload)
        tabCount = findViewById(R.id.tabCount)

        setupAddressBar()
        setupButtons()

        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    handleBack()
                }
            }
        )

        val startUrl = intent?.getStringExtra("open_url") ?: intent?.dataString
        newTab(startUrl ?: NEWTAB_URL)
        handleIntentExtras(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val url = intent.getStringExtra("open_url") ?: intent.dataString
        if (url != null) newTab(url)
        handleIntentExtras(intent)
    }

    override fun onResume() {
        super.onResume()
        current?.webView?.onResume()
        // Ayarlar ekranında değişen seçenekleri açık sekmelere uygula
        for (tab in tabs) {
            applyViewPrefs(tab.webView)
            applyNight(tab)
        }
    }

    override fun onPause() {
        current?.webView?.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        for (tab in tabs) {
            webContainer.removeView(tab.webView)
            tab.webView.destroy()
        }
        tabs.clear()
        super.onDestroy()
    }

    // ---------------------------------------------------------------------------------------
    // Arayüz kurulumu
    // ---------------------------------------------------------------------------------------

    private fun setupAddressBar() {
        addressBar.setOnFocusChangeListener { view, hasFocus ->
            if (!hasFocus) {
                hideKeyboard(view)
                updateUi()
            }
        }
        addressBar.setOnEditorActionListener { _, actionId, event ->
            val enterPressed = event != null &&
                event.keyCode == KeyEvent.KEYCODE_ENTER &&
                event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_GO || enterPressed) {
                loadFromInput(addressBar.text.toString())
                addressBar.clearFocus()
                current?.webView?.requestFocus()
                true
            } else {
                false
            }
        }
    }

    private fun setupButtons() {
        btnBack.setOnClickListener {
            val webView = current?.webView
            if (webView != null && webView.canGoBack()) webView.goBack()
        }
        btnForward.setOnClickListener {
            val webView = current?.webView
            if (webView != null && webView.canGoForward()) webView.goForward()
        }
        findViewById<ImageButton>(R.id.btnHome).setOnClickListener {
            current?.webView?.loadUrl(NEWTAB_URL)
        }
        btnReload.setOnClickListener {
            val tab = current
            if (tab != null) {
                if (tab.loading) {
                    tab.webView.stopLoading()
                    tab.loading = false
                    updateUi()
                    updateProgress()
                } else {
                    tab.webView.reload()
                }
            }
        }
        findViewById<ImageButton>(R.id.btnTabs).setOnClickListener { showTabs() }
        findViewById<ImageButton>(R.id.btnMenu).setOnClickListener { showMenu() }
        findViewById<ImageButton>(R.id.btnMic).setOnClickListener { startVoiceSearch() }
    }

    // ---------------------------------------------------------------------------------------
    // Sekme yönetimi
    // ---------------------------------------------------------------------------------------

    @SuppressLint("SetJavaScriptEnabled")
    private fun newTab(url: String?, isPrivate: Boolean = false): BrowserTab {
        val webView = WebView(this)
        val tab = BrowserTab(webView, isPrivate)

        webView.setBackgroundColor(getColor(R.color.bg))
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        settings.setSupportZoom(true)
        settings.setSupportMultipleWindows(true)
        settings.javaScriptCanOpenWindowsAutomatically = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.allowFileAccess = true
        settings.allowContentAccess = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        if (isPrivate) {
            settings.cacheMode = WebSettings.LOAD_NO_CACHE
            @Suppress("DEPRECATION")
            settings.saveFormData = false
        }
        applyUserAgent(webView)
        applyViewPrefs(webView)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val uri = request?.url
                if (uri?.scheme == HOME_SCHEME) return handleHomeAction(uri)
                return handleExternalScheme(uri)
            }

            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): android.webkit.WebResourceResponse? {
                val reqUrl = request?.url?.toString()
                if (reqUrl != null && VIDEO_EXT.containsMatchIn(reqUrl.substringBefore('?'))) {
                    tab.videoUrl = reqUrl
                }
                if (request != null && prefs.adBlock && !request.isForMainFrame &&
                    AdBlocker.shouldBlock(request.url?.toString(), request.url?.host)
                ) {
                    return AdBlocker.emptyResponse()
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                val focusHost = Uri.parse(url.orEmpty()).host
                if (prefs.isFocusBlocked(focusHost)) {
                    view?.stopLoading()
                    view?.loadDataWithBaseURL(null, focusHtml(), "text/html", "utf-8", null)
                    return
                }
                tab.videoUrl = null
                tab.loading = true
                tab.progress = 5
                tab.url = url.orEmpty()
                if (tab === current) {
                    updateUi()
                    updateProgress()
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                tab.loading = false
                tab.progress = 100
                tab.url = url.orEmpty()
                tab.title = view?.title.orEmpty()
                if (!tab.isPrivate) prefs.addHistory(tab.title, tab.url)
                if (tab.url.startsWith(NEWTAB_URL)) renderDials(tab)
                injectPageScripts(tab)
                if (tab === current) {
                    updateUi()
                    updateProgress()
                }
            }

            override fun onPageCommitVisible(view: WebView?, url: String?) {
                // Gece modunu sayfa görünür olur olmaz uygula (beyaz parlama olmasın)
                tab.url = url.orEmpty()
                applyNight(tab)
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                tab.url = url.orEmpty()
                if (tab === current) updateUi()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                tab.progress = newProgress
                if (tab === current) updateProgress()
            }

            override fun onReceivedIcon(view: WebView?, icon: Bitmap?) {
                tab.favicon = icon
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                tab.title = title.orEmpty()
            }

            // target="_blank" ve window.open bağlantıları yeni sekmede açılır
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?
            ): Boolean {
                if (prefs.adBlock && !isUserGesture) return false // kullanıcı dokunmadan açılan pencereler engellenir
                val message = resultMsg ?: return false
                val transport = message.obj as? WebView.WebViewTransport ?: return false
                val created = newTab(null, tab.isPrivate)
                transport.webView = created.webView
                message.sendToTarget()
                return true
            }

            override fun onShowCustomView(
                view: View?,
                callback: WebChromeClient.CustomViewCallback?
            ) {
                if (view == null || customView != null) {
                    callback?.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                fullscreenContainer.addView(view)
                fullscreenContainer.visibility = View.VISIBLE
                setSystemBarsVisible(false)
            }

            override fun onHideCustomView() {
                exitFullscreen()
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                val chooserIntent = fileChooserParams?.createIntent() ?: return false
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                return try {
                    fileChooser.launch(chooserIntent)
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }

        webView.setDownloadListener { downloadUrl, userAgent, contentDisposition, mimeType, _ ->
            startDownload(downloadUrl, userAgent, contentDisposition, mimeType)
        }

        webView.setOnLongClickListener {
            val hit = webView.hitTestResult
            val extra: String? = hit.extra
            val type = hit.type
            val linkable = type == WebView.HitTestResult.SRC_ANCHOR_TYPE ||
                type == WebView.HitTestResult.IMAGE_TYPE ||
                type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE
            if (linkable && extra != null && extra.startsWith("http")) {
                showLinkMenu(tab, type, extra)
                true
            } else {
                false
            }
        }

        tabs.add(tab)
        switchTo(tab)
        if (url != null) webView.loadUrl(normalizeInput(url))
        return tab
    }

    private fun switchTo(tab: BrowserTab) {
        val previous = current
        if (previous != null && previous !== tab) {
            captureThumb(previous)
            previous.webView.onPause()
            webContainer.removeView(previous.webView)
        }
        current = tab
        (tab.webView.parent as? ViewGroup)?.removeView(tab.webView)
        webContainer.addView(
            tab.webView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        tab.webView.onResume()
        updateUi()
        updateProgress()
    }

    private fun closeTab(tab: BrowserTab) {
        val index = tabs.indexOf(tab)
        if (index < 0) return
        tabs.removeAt(index)

        val wasCurrent = tab === current
        if (wasCurrent) current = null
        webContainer.removeView(tab.webView)
        tab.webView.stopLoading()
        tab.webView.destroy()

        if (tabs.isEmpty()) {
            newTab(NEWTAB_URL)
        } else if (wasCurrent) {
            switchTo(tabs[minOf(index, tabs.size - 1)])
        } else {
            updateUi()
        }
    }

    // ---------------------------------------------------------------------------------------
    // Arayüzü güncelleme
    // ---------------------------------------------------------------------------------------

    private fun updateUi() {
        val tab = current ?: return
        val webView = tab.webView

        val canBack = webView.canGoBack()
        val canForward = webView.canGoForward()
        btnBack.isEnabled = canBack
        btnBack.alpha = if (canBack) 1f else 0.35f
        btnForward.isEnabled = canForward
        btnForward.alpha = if (canForward) 1f else 0.35f

        btnReload.setImageResource(if (tab.loading) R.drawable.ic_close else R.drawable.ic_refresh)
        tabCount.text = tabs.size.toString()

        topBar.setBackgroundResource(
            if (tab.isPrivate) R.drawable.bg_bar_top_private else R.drawable.bg_bar_top
        )
        bottomBar.setBackgroundResource(
            if (tab.isPrivate) R.drawable.bg_bar_bottom_private else R.drawable.bg_bar_bottom
        )
        if (tab.isPrivate && prefs.secureTabs) {
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }

        val secure = tab.url.startsWith("https://")
        addressIcon.setImageResource(if (secure) R.drawable.ic_lock else R.drawable.ic_search)

        if (!addressBar.hasFocus()) {
            addressBar.setText(displayUrl(tab.url))
        }
    }

    private fun updateProgress() {
        val tab = current ?: return
        val showBar = tab.loading && tab.progress < 100
        progressBar.visibility = if (showBar) View.VISIBLE else View.INVISIBLE
        progressBar.progress = tab.progress
    }

    private fun displayUrl(url: String): String {
        return if (url.isBlank() || url.startsWith(NEWTAB_URL)) "" else url
    }

    private fun tabLabel(tab: BrowserTab): String {
        if (tab.title.isNotBlank()) return tab.title
        val host = Uri.parse(tab.url).host
        return if (!host.isNullOrBlank()) host else getString(R.string.new_tab)
    }

    // ---------------------------------------------------------------------------------------
    // Sekme listesi ve menü
    // ---------------------------------------------------------------------------------------

    /** Sekmenin küçük bir önizlemesini alır (gizli sekmelerde alınmaz). */
    private fun captureThumb(tab: BrowserTab) {
        if (tab.isPrivate) return
        val w = tab.webView
        if (w.width <= 0 || w.height <= 0) return
        try {
            val scale = 0.4f
            val bmp = Bitmap.createBitmap(
                (w.width * scale).toInt().coerceAtLeast(1),
                (w.height * scale).toInt().coerceAtLeast(1),
                Bitmap.Config.ARGB_8888
            )
            val canvas = Canvas(bmp)
            canvas.scale(scale, scale)
            w.draw(canvas)
            // Kartta sayfanın üst kısmı görünsün
            val keep = minOf(bmp.height, (bmp.width * 1.15f).toInt())
            tab.thumb = Bitmap.createBitmap(bmp, 0, 0, bmp.width, keep)
        } catch (e: Throwable) {
            // Önizleme alınamazsa yer tutucu gösterilir
        }
    }

    private fun showTabs() {
        current?.let { captureThumb(it) }
        val dialog = Dialog(this, R.style.Theme_Gokboru_Tabs)
        val root = layoutInflater.inflate(R.layout.dialog_tabs, null)
        val grid = root.findViewById<LinearLayout>(R.id.tabsGrid)
        val empty = root.findViewById<View>(R.id.tabsEmpty)
        val normalBtn = root.findViewById<TextView>(R.id.tabsNormal)
        val privateBtn = root.findViewById<ImageView>(R.id.tabsPrivate)
        val search = root.findViewById<EditText>(R.id.tabsSearch)
        var showPrivate = current?.isPrivate == true

        fun populate() {
            val normalCount = tabs.count { !it.isPrivate }
            normalBtn.text = normalCount.toString()
            val gold = android.content.res.ColorStateList.valueOf(getColor(R.color.gold))
            val dark = android.content.res.ColorStateList.valueOf(getColor(R.color.night))
            if (showPrivate) {
                normalBtn.setBackgroundResource(0)
                normalBtn.setTextColor(getColor(R.color.gold))
                privateBtn.setBackgroundResource(R.drawable.bg_pill_selected)
                privateBtn.imageTintList = dark
            } else {
                normalBtn.setBackgroundResource(R.drawable.bg_pill_selected)
                normalBtn.setTextColor(getColor(R.color.night))
                privateBtn.setBackgroundResource(0)
                privateBtn.imageTintList = gold
            }

            val query = search.text.toString().trim().lowercase()
            val shown = tabs.filter { t ->
                t.isPrivate == showPrivate &&
                    (query.isEmpty() ||
                        tabLabel(t).lowercase().contains(query) ||
                        t.url.lowercase().contains(query))
            }
            grid.removeAllViews()
            empty.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE

            var i = 0
            while (i < shown.size) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                for (k in 0..1) {
                    val tab = shown.getOrNull(i + k)
                    if (tab == null) {
                        row.addView(
                            View(this),
                            LinearLayout.LayoutParams(0, 1, 1f).apply {
                                setMargins(dp(5), 0, dp(5), 0)
                            }
                        )
                        continue
                    }
                    val card = layoutInflater.inflate(R.layout.item_tab_card, row, false)
                    val active = tab === current
                    card.setBackgroundResource(
                        when {
                            active -> R.drawable.bg_tab_card_active
                            tab.isPrivate -> R.drawable.bg_tab_card_private
                            else -> R.drawable.bg_tab_card
                        }
                    )
                    val title = card.findViewById<TextView>(R.id.cardTitle)
                    title.text = tabLabel(tab)
                    title.setTextColor(getColor(if (active) R.color.night else R.color.text))
                    card.findViewById<ImageButton>(R.id.cardClose).imageTintList =
                        android.content.res.ColorStateList.valueOf(
                            getColor(if (active) R.color.night else R.color.text)
                        )
                    val icon = card.findViewById<ImageView>(R.id.cardIcon)
                    val favicon = tab.favicon
                    if (favicon != null && !tab.isPrivate) {
                        icon.imageTintList = null
                        icon.setImageBitmap(favicon)
                    } else {
                        icon.setImageResource(
                            if (tab.isPrivate) R.drawable.ic_incognito else R.drawable.ic_search
                        )
                        icon.imageTintList = android.content.res.ColorStateList.valueOf(
                            getColor(if (active) R.color.night else R.color.gold)
                        )
                    }
                    val thumbView = card.findViewById<ImageView>(R.id.cardThumb)
                    val placeholder = card.findViewById<ImageView>(R.id.cardPlaceholder)
                    val thumb = tab.thumb
                    if (thumb != null && !tab.isPrivate) {
                        thumbView.setImageBitmap(thumb)
                        placeholder.visibility = View.GONE
                    } else if (tab.isPrivate) {
                        placeholder.setImageResource(R.drawable.ic_incognito)
                        placeholder.imageTintList =
                            android.content.res.ColorStateList.valueOf(getColor(R.color.gold))
                    }
                    card.setOnClickListener {
                        switchTo(tab)
                        dialog.dismiss()
                    }
                    card.findViewById<ImageButton>(R.id.cardClose).setOnClickListener {
                        closeTab(tab)
                        if (tabs.none { it.isPrivate == showPrivate }) {
                            showPrivate = current?.isPrivate == true
                        }
                        populate()
                    }
                    row.addView(card)
                }
                grid.addView(row)
                i += 2
            }
        }

        normalBtn.setOnClickListener { showPrivate = false; populate() }
        privateBtn.setOnClickListener { showPrivate = true; populate() }
        search.doAfterTextChanged { populate() }

        root.findViewById<View>(R.id.tabsNew).setOnClickListener {
            val wasPrivate = showPrivate
            dialog.dismiss()
            newTab(NEWTAB_URL, wasPrivate)
            if (!wasPrivate) focusAddress()
        }
        root.findViewById<View>(R.id.tabsMore).setOnClickListener { anchor ->
            val popup = PopupMenu(this, anchor)
            popup.menu.add(0, 1, 0, getString(R.string.tabs_close_all))
            popup.menu.add(0, 2, 1, getString(R.string.tabs_close_private))
            popup.setOnMenuItemClickListener { item ->
                val onlyPrivate = item.itemId == 2
                for (t in tabs.filter { !onlyPrivate || it.isPrivate }) closeTab(t)
                dialog.dismiss()
                true
            }
            popup.show()
        }

        populate()
        dialog.setContentView(root)
        dialog.window?.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        dialog.show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun showMenu() {
        val dialog = BottomSheetDialog(this)
        val sheet = layoutInflater.inflate(R.layout.sheet_list, null)
        sheet.findViewById<View>(R.id.listTitle).visibility = View.GONE
        val body = sheet.findViewById<LinearLayout>(R.id.listBody)

        val header = layoutInflater.inflate(R.layout.menu_header, body, false)
        header.findViewById<View>(R.id.menuSettings).setOnClickListener {
            dialog.dismiss()
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        header.setOnClickListener {
            dialog.dismiss()
            startActivity(Intent(this, ProfileActivity::class.java))
        }
        body.addView(header)
        addQuickRow(body)

        val tab = current
        val pageUrl = tab?.url.orEmpty()
        val realPage = pageUrl.isNotBlank() && !pageUrl.startsWith(NEWTAB_URL)

        addRow(body, R.drawable.ic_plus, getString(R.string.menu_new_tab), null, null) {
            dialog.dismiss()
            newTab(NEWTAB_URL)
            focusAddress()
        }
        addRow(body, R.drawable.ic_incognito, getString(R.string.menu_new_private), null, null) {
            dialog.dismiss()
            newTab(NEWTAB_URL, true)
        }
        if (realPage) {
            val fav = prefs.isFavorite(pageUrl)
            addRow(
                body, R.drawable.ic_star,
                getString(if (fav) R.string.favorite_removed else R.string.menu_add_favorite),
                null, null
            ) {
                dialog.dismiss()
                val added = prefs.toggleFavorite(tab?.title.orEmpty(), pageUrl)
                Toast.makeText(
                    this,
                    if (added) R.string.favorite_added else R.string.favorite_removed,
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        addRow(body, R.drawable.ic_star, getString(R.string.menu_favorites), null, null) {
            dialog.dismiss()
            showFavorites()
        }
        addRow(body, R.drawable.ic_history, getString(R.string.menu_history), null, null) {
            dialog.dismiss()
            showHistory()
        }
        addRow(body, R.drawable.ic_download, getString(R.string.menu_downloads), null, null) {
            dialog.dismiss()
            startActivity(Intent(this, DownloadsActivity::class.java))
        }
        addRow(body, R.drawable.ic_offline, getString(R.string.offline_title), null, null) {
            dialog.dismiss()
            startActivity(Intent(this, OfflinePagesActivity::class.java))
        }
        addRow(
            body, R.drawable.ic_shield, getString(R.string.menu_adblock_short),
            getString(R.string.adblock_count, AdBlocker.blocked.get()), prefs.adBlock
        ) {
            prefs.adBlock = !prefs.adBlock
            current?.webView?.reload()
        }
        addRow(
            body, R.drawable.ic_timer, getString(R.string.focus_title),
            if (prefs.focusActive()) getString(R.string.focus_sub_on, prefs.focusMinutesLeft()) else null,
            null
        ) {
            dialog.dismiss()
            showFocusDialog()
        }
        addRow(
            body, R.drawable.ic_apps, getString(R.string.toolbox_title),
            if (current?.videoUrl != null) getString(R.string.toolbox_video_found) else null, null
        ) {
            dialog.dismiss()
            showToolbox()
        }
        addRow(body, R.drawable.ic_text, getString(R.string.menu_text_size), "${prefs.textZoom}%", null) {
            dialog.dismiss()
            showTextSizeDialog()
        }
        if (realPage) {
            addRow(body, R.drawable.ic_offline, getString(R.string.offline_save), null, null) {
                dialog.dismiss()
                saveOffline()
            }
            addRow(body, R.drawable.ic_copy, getString(R.string.menu_copy_link), null, null) {
                dialog.dismiss()
                copyText(pageUrl)
            }
        }
        addRow(body, R.drawable.ic_settings, getString(R.string.menu_settings), null, null) {
            dialog.dismiss()
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        val phoneRow = addRow(
            body, R.drawable.ic_home, getString(R.string.menu_phone_view), null, null,
            radioState = !desktopMode
        ) {
            dialog.dismiss()
            setDesktopMode(false)
        }
        val desktopRow = addRow(
            body, R.drawable.ic_desktop, getString(R.string.menu_desktop_view), null, null,
            radioState = desktopMode
        ) {
            dialog.dismiss()
            setDesktopMode(true)
        }
        if (phoneRow == desktopRow) return // asla olmaz; yalnızca değişkenlerin kullanıldığını belirtir

        if (realPage) {
            addRow(body, R.drawable.ic_share, getString(R.string.menu_share), null, null) {
                dialog.dismiss()
                shareCurrentPage()
            }
        }
        addRow(body, R.drawable.ic_close, getString(R.string.menu_exit), null, null) {
            dialog.dismiss()
            finishAffinity()
        }

        dialog.setContentView(sheet)
        dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        dialog.show()
    }

    // ---------------------------------------------------------------------------------------
    // Hızlı anahtarlar, çevrimdışı sayfa, hızlı erişim kısayolları, Odak Modu
    // ---------------------------------------------------------------------------------------

    private fun addQuickRow(container: LinearLayout) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(0, dp(4), 0, dp(10))
        quickTile(row, R.drawable.ic_leaf, getString(R.string.quick_data), prefs.blockImages) { on ->
            prefs.blockImages = on
            for (t in tabs) applyViewPrefs(t.webView)
        }
        quickTile(row, R.drawable.ic_shield, getString(R.string.quick_ads), prefs.adBlock) { on ->
            prefs.adBlock = on
            current?.webView?.reload()
        }
        quickTile(row, R.drawable.ic_moon, getString(R.string.quick_night), prefs.nightMode) { on ->
            prefs.nightMode = on
            for (t in tabs) applyNight(t)
        }
        container.addView(row)
    }

    private fun quickTile(
        row: LinearLayout,
        icon: Int,
        name: String,
        initial: Boolean,
        onToggle: (Boolean) -> Unit
    ) {
        val tile = layoutInflater.inflate(R.layout.item_quick, row, false)
        val iconView = tile.findViewById<ImageView>(R.id.quickIcon)
        val nameView = tile.findViewById<TextView>(R.id.quickName)
        val stateView = tile.findViewById<TextView>(R.id.quickState)
        iconView.setImageResource(icon)
        nameView.text = name
        var on = initial
        fun paint() {
            iconView.setBackgroundResource(if (on) R.drawable.bg_quick_on else R.drawable.bg_quick)
            iconView.imageTintList = android.content.res.ColorStateList.valueOf(
                getColor(if (on) R.color.night else R.color.text)
            )
            stateView.setText(if (on) R.string.state_on else R.string.state_off)
        }
        paint()
        tile.setOnClickListener {
            on = !on
            onToggle(on)
            paint()
        }
        row.addView(tile)
    }

    private fun saveOffline() {
        val tab = current ?: return
        val dir = java.io.File(filesDir, "offline")
        dir.mkdirs()
        val file = java.io.File(dir, "page_" + System.currentTimeMillis() + ".mht")
        val title = tabLabel(tab)
        tab.webView.saveWebArchive(file.absolutePath, false) { saved ->
            if (saved != null) {
                prefs.addOffline(title, saved)
                Toast.makeText(this, R.string.offline_saved, Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, R.string.offline_failed, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun renderDials(tab: BrowserTab) {
        val array = org.json.JSONArray()
        for (entry in prefs.speedDials()) {
            val obj = org.json.JSONObject()
            obj.put("t", entry.title)
            obj.put("u", entry.url)
            array.put(obj)
        }
        tab.webView.evaluateJavascript("renderDial(" + array.toString() + ")", null)
    }

    private fun refreshDials() {
        for (t in tabs) {
            if (t.url.startsWith(NEWTAB_URL)) renderDials(t)
        }
    }

    private fun showAddDial() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(22), dp(8), dp(22), 0)
        val nameInput = EditText(this)
        nameInput.hint = getString(R.string.dial_name_hint)
        nameInput.setSingleLine()
        val urlInput = EditText(this)
        urlInput.hint = getString(R.string.dial_url_hint)
        urlInput.setSingleLine()
        urlInput.inputType = android.text.InputType.TYPE_CLASS_TEXT or
            android.text.InputType.TYPE_TEXT_VARIATION_URI
        box.addView(nameInput)
        box.addView(urlInput)
        AlertDialog.Builder(this)
            .setTitle(R.string.dial_add_title)
            .setView(box)
            .setPositiveButton(R.string.ok) { _, _ ->
                var url = urlInput.text.toString().trim()
                if (url.isNotEmpty()) {
                    if (!url.startsWith("http", true)) url = "https://$url"
                    val name = nameInput.text.toString().trim()
                        .ifEmpty { Uri.parse(url).host ?: url }
                    prefs.addSpeedDial(name, url)
                    refreshDials()
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun confirmRemoveDial(url: String?) {
        if (url.isNullOrEmpty()) return
        AlertDialog.Builder(this)
            .setTitle(R.string.dial_remove_title)
            .setMessage(url)
            .setPositiveButton(R.string.dl_delete) { _, _ ->
                prefs.removeSpeedDial(url)
                refreshDials()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun handleIntentExtras(intent: Intent?) {
        if (intent?.getStringExtra("action") == "focus") showFocusDialog()
    }

    private fun focusHtml(): String {
        val left = getString(R.string.focus_block_left, prefs.focusMinutesLeft())
        val title = getString(R.string.focus_block_title)
        val text = getString(R.string.focus_block_text)
        return "<html><head><meta charset='utf-8'>" +
            "<meta name='viewport' content='width=device-width,initial-scale=1'>" +
            "<style>body{margin:0;min-height:100vh;display:flex;align-items:center;" +
            "justify-content:center;background:#040E16;color:#F3E7C9;" +
            "font-family:sans-serif;text-align:center}.b{padding:28px;max-width:340px}" +
            "h1{color:#F5B942;font-size:26px;margin:14px 0 8px}p{color:#B7A77F;line-height:1.5}" +
            ".t{display:inline-block;margin-top:14px;padding:10px 20px;border-radius:999px;" +
            "border:1px solid #F5B942;color:#F5B942}</style></head><body><div class='b'>" +
            "<div style='font-size:60px'>&#128058;</div><h1>" + title + "</h1><p>" + text +
            "</p><div class='t'>" + left + "</div></div></body></html>"
    }

    private fun showFocusDialog() {
        if (prefs.focusActive()) {
            AlertDialog.Builder(this)
                .setTitle(R.string.focus_title)
                .setMessage(
                    getString(
                        R.string.focus_running,
                        prefs.focusMinutesLeft(),
                        Prefs.FOCUS_SITES.joinToString(", ")
                    )
                )
                .setPositiveButton(R.string.focus_stop) { _, _ ->
                    prefs.focusUntil = 0L
                    Toast.makeText(this, R.string.focus_stopped, Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
            return
        }
        val labels = Prefs.FOCUS_MINUTES.map { getString(R.string.focus_minutes, it) }.toTypedArray()
        var selected = 1
        AlertDialog.Builder(this)
            .setTitle(R.string.focus_title)
            .setSingleChoiceItems(labels, selected) { _, which -> selected = which }
            .setPositiveButton(R.string.focus_start) { _, _ ->
                val minutes = Prefs.FOCUS_MINUTES[selected]
                prefs.focusUntil = System.currentTimeMillis() + minutes * 60000L
                Toast.makeText(
                    this,
                    getString(R.string.focus_started, minutes),
                    Toast.LENGTH_LONG
                ).show()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ---------------------------------------------------------------------------------------
    // Araç Kutusu (QQ Browser tarzı): ekran görüntüsü, tam ekran, QR, video indir, ana ekrana ekle
    // ---------------------------------------------------------------------------------------

    private fun showToolbox() {
        val dialog = BottomSheetDialog(this)
        val sheet = layoutInflater.inflate(R.layout.sheet_list, null)
        sheet.findViewById<TextView>(R.id.listTitle).setText(R.string.toolbox_title)
        val body = sheet.findViewById<LinearLayout>(R.id.listBody)

        val tab = current
        val pageUrl = tab?.url.orEmpty()
        val realPage = pageUrl.isNotBlank() && !pageUrl.startsWith(NEWTAB_URL)
        val hasVideo = tab?.videoUrl != null

        class Tool(val icon: Int, val name: Int, val enabled: Boolean, val action: () -> Unit)

        val tools = listOf(
            Tool(R.drawable.ic_camera, R.string.tool_screenshot, realPage) { takeScreenshot() },
            Tool(R.drawable.ic_fullscreen, R.string.tool_fullscreen, true) { toggleImmersive() },
            Tool(R.drawable.ic_scan, R.string.tool_qr, true) { scanQr() },
            Tool(R.drawable.ic_add_box, R.string.tool_home_screen, realPage) { addToHomeScreen() },
            Tool(R.drawable.ic_download, R.string.tool_video, hasVideo) { downloadSniffedVideo() },
            Tool(R.drawable.ic_search, R.string.menu_find, realPage) { showFind() },
            Tool(R.drawable.ic_book, R.string.menu_reader, realPage) { startReaderMode() },
            Tool(R.drawable.ic_translate, R.string.menu_translate, realPage) {
                current?.webView?.loadUrl(
                    "https://translate.google.com/translate?sl=auto&tl=tr&u=" + Uri.encode(pageUrl)
                )
            }
        )

        var index = 0
        while (index < tools.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.setPadding(0, dp(4), 0, dp(8))
            for (k in 0..3) {
                val tool = tools.getOrNull(index + k)
                if (tool == null) {
                    row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
                    continue
                }
                val tile = layoutInflater.inflate(R.layout.item_quick, row, false)
                val icon = tile.findViewById<ImageView>(R.id.quickIcon)
                icon.setImageResource(tool.icon)
                icon.setBackgroundResource(R.drawable.bg_quick)
                icon.imageTintList = android.content.res.ColorStateList.valueOf(
                    getColor(if (tool.enabled) R.color.gold else R.color.muted)
                )
                tile.findViewById<TextView>(R.id.quickName).setText(tool.name)
                tile.findViewById<View>(R.id.quickState).visibility = View.GONE
                tile.alpha = if (tool.enabled) 1f else 0.4f
                tile.setOnClickListener {
                    if (tool.enabled) {
                        dialog.dismiss()
                        tool.action()
                    }
                }
                row.addView(tile)
            }
            body.addView(row)
            index += 4
        }

        dialog.setContentView(sheet)
        dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        dialog.show()
    }

    /** Sadece görünen kısmın ekran görüntüsünü Resimler/Gokboru klasörüne kaydeder. */
    private fun takeScreenshot() {
        val webView = current?.webView ?: return
        if (webView.width <= 0 || webView.height <= 0) return
        try {
            val bitmap = Bitmap.createBitmap(webView.width, webView.height, Bitmap.Config.ARGB_8888)
            webView.draw(Canvas(bitmap))
            val name = "Gokboru_" + System.currentTimeMillis() + ".png"
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues()
                values.put(MediaStore.Images.Media.DISPLAY_NAME, name)
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Gokboru")
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri == null) {
                    Toast.makeText(this, R.string.screenshot_failed, Toast.LENGTH_SHORT).show()
                    return
                }
                contentResolver.openOutputStream(uri)?.use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                Toast.makeText(this, R.string.screenshot_saved, Toast.LENGTH_SHORT).show()
            } else {
                val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
                if (dir == null) {
                    Toast.makeText(this, R.string.screenshot_failed, Toast.LENGTH_SHORT).show()
                    return
                }
                val file = java.io.File(dir, name)
                java.io.FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                Toast.makeText(this, getString(R.string.screenshot_saved_to, file.absolutePath), Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, R.string.screenshot_failed, Toast.LENGTH_SHORT).show()
        }
    }

    /** Adres ve alt çubukları gizleyip sayfayı tam ekran gösterir. Geri tuşu çıkarır. */
    private fun toggleImmersive() {
        immersive = !immersive
        val visibility = if (immersive) View.GONE else View.VISIBLE
        topBar.visibility = visibility
        bottomBar.visibility = visibility
        if (immersive) progressBar.visibility = View.GONE else updateProgress()
        setSystemBarsVisible(!immersive)
        if (immersive) Toast.makeText(this, R.string.fullscreen_hint, Toast.LENGTH_SHORT).show()
    }

    private fun scanQr() {
        try {
            com.google.mlkit.vision.codescanner.GmsBarcodeScanning.getClient(this)
                .startScan()
                .addOnSuccessListener { barcode ->
                    val text = barcode.rawValue
                    if (!text.isNullOrBlank()) loadFromInput(text)
                }
                .addOnFailureListener {
                    Toast.makeText(this, R.string.qr_failed, Toast.LENGTH_SHORT).show()
                }
        } catch (e: Exception) {
            Toast.makeText(this, R.string.qr_failed, Toast.LENGTH_SHORT).show()
        }
    }

    private fun addToHomeScreen() {
        val tab = current ?: return
        val url = tab.url
        if (url.isBlank() || !ShortcutManagerCompat.isRequestPinShortcutSupported(this)) {
            Toast.makeText(this, R.string.home_shortcut_failed, Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(this, MainActivity::class.java)
        intent.action = Intent.ACTION_VIEW
        intent.data = Uri.parse(url)
        val favicon = tab.favicon
        val icon = if (favicon != null && !tab.isPrivate) {
            IconCompat.createWithBitmap(favicon)
        } else {
            IconCompat.createWithResource(this, R.mipmap.ic_launcher_round)
        }
        val shortcut = ShortcutInfoCompat.Builder(this, "site_" + url.hashCode())
            .setShortLabel(tabLabel(tab).take(24))
            .setIcon(icon)
            .setIntent(intent)
            .build()
        ShortcutManagerCompat.requestPinShortcut(this, shortcut, null)
    }

    private fun downloadSniffedVideo() {
        val tab = current ?: return
        val url = tab.videoUrl
        if (url == null) {
            Toast.makeText(this, R.string.video_not_found, Toast.LENGTH_SHORT).show()
            return
        }
        startDownload(url, tab.webView.settings.userAgentString, null, "video/mp4")
    }

    private fun openDownloads() {
        try {
            startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
        } catch (e: Exception) {
            Toast.makeText(this, R.string.download_failed, Toast.LENGTH_SHORT).show()
        }
    }

    /** Menü/liste satırı ekler. switchState null değilse sağda anahtar gösterilir. */
    private fun addRow(
        container: LinearLayout,
        icon: Int,
        title: String,
        sub: String?,
        switchState: Boolean?,
        radioState: Boolean? = null,
        onClick: () -> Unit
    ): View {
        val row = layoutInflater.inflate(R.layout.item_row, container, false)
        row.findViewById<ImageView>(R.id.rowIcon).setImageResource(icon)
        row.findViewById<TextView>(R.id.rowTitle).text = title
        val subView = row.findViewById<TextView>(R.id.rowSub)
        if (!sub.isNullOrBlank()) {
            subView.text = sub
            subView.visibility = View.VISIBLE
        }
        val switch = row.findViewById<SwitchCompat>(R.id.rowSwitch)
        if (radioState != null) {
            val radio = row.findViewById<android.widget.RadioButton>(R.id.rowRadio)
            radio.visibility = View.VISIBLE
            radio.isChecked = radioState
            row.setOnClickListener { onClick() }
        } else if (switchState != null) {
            switch.visibility = View.VISIBLE
            switch.isChecked = switchState
            row.setOnClickListener {
                switch.isChecked = !switch.isChecked
                onClick()
            }
        } else {
            row.setOnClickListener { onClick() }
        }
        container.addView(row)
        return row
    }

    private fun showFavorites() {
        showEntries(R.string.menu_favorites, prefs.favorites(), R.string.empty_favorites, false)
    }

    private fun showHistory() {
        showEntries(R.string.menu_history, prefs.history(), R.string.empty_history, true)
    }

    private fun showEntries(titleRes: Int, entries: List<Prefs.Entry>, emptyRes: Int, isHistory: Boolean) {
        val dialog = BottomSheetDialog(this)
        val sheet = layoutInflater.inflate(R.layout.sheet_list, null)
        sheet.findViewById<TextView>(R.id.listTitle).setText(titleRes)
        val body = sheet.findViewById<LinearLayout>(R.id.listBody)

        if (entries.isEmpty()) {
            val empty = TextView(this)
            empty.setText(emptyRes)
            empty.setTextColor(getColor(R.color.muted))
            empty.setPadding(16, 24, 16, 24)
            body.addView(empty)
        }
        if (isHistory && entries.isNotEmpty()) {
            addRow(body, R.drawable.ic_trash, getString(R.string.clear_history), null, null) {
                prefs.clearHistory()
                dialog.dismiss()
                Toast.makeText(this, R.string.history_cleared, Toast.LENGTH_SHORT).show()
            }
        }
        for (entry in entries) {
            val row = addRow(
                body,
                if (isHistory) R.drawable.ic_history else R.drawable.ic_star,
                entry.title,
                entry.url,
                null
            ) {
                dialog.dismiss()
                current?.webView?.loadUrl(entry.url)
            }
            if (!isHistory) {
                row.setOnLongClickListener {
                    prefs.toggleFavorite(entry.title, entry.url)
                    dialog.dismiss()
                    Toast.makeText(this, R.string.favorite_removed, Toast.LENGTH_SHORT).show()
                    true
                }
            }
        }

        dialog.setContentView(sheet)
        dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        dialog.show()
    }

    /** Ana sayfadaki gokboru:// bağlantıları. */
    private fun handleHomeAction(uri: Uri): Boolean {
        when (uri.host) {
            "favorites" -> showFavorites()
            "history" -> showHistory()
            "private" -> newTab(NEWTAB_URL, true)
            "tabs" -> showTabs()
            "mobile" -> setDesktopMode(false)
            "desktop" -> setDesktopMode(true)
            "adblock" -> {
                prefs.adBlock = !prefs.adBlock
                Toast.makeText(
                    this,
                    if (prefs.adBlock) R.string.adblock_on else R.string.adblock_off,
                    Toast.LENGTH_SHORT
                ).show()
            }
            "settings" -> startActivity(Intent(this, SettingsActivity::class.java))
            "adddial" -> showAddDial()
            "removedial" -> confirmRemoveDial(uri.getQueryParameter("u"))
        }
        return true
    }

    private fun startVoiceSearch() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(
            RecognizerIntent.EXTRA_LANGUAGE_MODEL,
            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
        )
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.voice_prompt))
        try {
            voiceLauncher.launch(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.voice_unavailable, Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Üst veya alt çubuk üzerinde kaydırma hareketleri:
     * sağa = geri, sola = ileri, yukarı = yeni sekme, aşağı = menü.
     */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                gestureStartX = ev.rawX
                gestureStartY = ev.rawY
                gestureOnBar = prefs.gestures &&
                    (isOverView(topBar, ev) || isOverView(bottomBar, ev))
            }
            MotionEvent.ACTION_UP -> {
                if (gestureOnBar) {
                    gestureOnBar = false
                    val dx = ev.rawX - gestureStartX
                    val dy = ev.rawY - gestureStartY
                    val minDistance = resources.displayMetrics.density * 80f
                    val horizontal = Math.abs(dx) > minDistance && Math.abs(dy) < Math.abs(dx) / 2
                    val vertical = Math.abs(dy) > minDistance && Math.abs(dx) < Math.abs(dy) / 2
                    if (horizontal || vertical) {
                        ev.action = MotionEvent.ACTION_CANCEL
                        super.dispatchTouchEvent(ev)
                        val webView = current?.webView
                        if (horizontal) {
                            if (dx > 0) {
                                if (webView != null && webView.canGoBack()) webView.goBack()
                            } else {
                                if (webView != null && webView.canGoForward()) webView.goForward()
                            }
                        } else if (dy < 0) {
                            newTab(NEWTAB_URL)
                        } else {
                            showMenu()
                        }
                        return true
                    }
                }
            }
            MotionEvent.ACTION_CANCEL -> gestureOnBar = false
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun isOverView(view: View, ev: MotionEvent): Boolean {
        val loc = IntArray(2)
        view.getLocationOnScreen(loc)
        return ev.rawX >= loc[0] && ev.rawX <= loc[0] + view.width &&
            ev.rawY >= loc[1] && ev.rawY <= loc[1] + view.height
    }

    private fun shareCurrentPage() {
        val url = current?.url.orEmpty()
        if (url.isBlank() || url.startsWith(NEWTAB_URL)) return
        val send = Intent(Intent.ACTION_SEND)
        send.type = "text/plain"
        send.putExtra(Intent.EXTRA_TEXT, url)
        startActivity(Intent.createChooser(send, getString(R.string.share_via)))
    }

    private fun setDesktopMode(enabled: Boolean) {
        if (desktopMode == enabled) return
        desktopMode = enabled
        for (tab in tabs) applyUserAgent(tab.webView)
        val url = current?.url.orEmpty()
        if (url.isNotBlank() && !url.startsWith(NEWTAB_URL)) current?.webView?.reload()
    }

    private fun applyUserAgent(webView: WebView) {
        webView.settings.userAgentString = if (desktopMode) DESKTOP_UA else mobileUserAgent
    }

    private fun clearBrowsingData() {
        CookieManager.getInstance().removeAllCookies(null)
        WebStorage.getInstance().deleteAllData()
        prefs.clearHistory()
        for (tab in tabs) {
            tab.webView.clearCache(true)
            tab.webView.clearHistory()
        }
        Toast.makeText(this, R.string.data_cleared, Toast.LENGTH_SHORT).show()
        updateUi()
    }

    // ---------------------------------------------------------------------------------------
    // Gezinme yardımcıları
    // ---------------------------------------------------------------------------------------

    private fun loadFromInput(input: String) {
        val text = input.trim()
        if (text.isEmpty()) return
        current?.webView?.loadUrl(normalizeInput(text))
    }

    private fun normalizeInput(input: String): String {
        val text = input.trim()
        if (text.isEmpty()) return NEWTAB_URL
        if (Regex("^(https?|file|about):", RegexOption.IGNORE_CASE).containsMatchIn(text)) {
            return text
        }
        if (!text.contains(' ')) {
            val localHost = Regex("^localhost(:\\d+)?([/?#].*)?$", RegexOption.IGNORE_CASE)
            val ipAddress = Regex("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?([/?#].*)?$")
            val domain = Regex("^[\\w-]+(\\.[\\w-]+)+(:\\d+)?([/?#].*)?$")
            if (localHost.matches(text) || ipAddress.matches(text)) return "http://$text"
            if (domain.matches(text)) return "https://$text"
        }
        return prefs.searchUrl() + Uri.encode(text)
    }

    /** http/https dışındaki bağlantıları (tel:, mailto:, intent: ...) ilgili uygulamaya verir. */
    private fun handleExternalScheme(uri: Uri?): Boolean {
        val scheme = uri?.scheme?.lowercase() ?: return false
        val internalSchemes = listOf("http", "https", "file", "about", "javascript", "data", "blob")
        if (scheme in internalSchemes) return false
        try {
            val intent = if (scheme == "intent") {
                Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
            } else {
                Intent(Intent.ACTION_VIEW, uri)
            }
            intent.addCategory(Intent.CATEGORY_BROWSABLE)
            intent.component = null
            intent.selector = null
            startActivity(intent)
        } catch (e: Exception) {
            // Açacak uygulama yoksa sessizce vazgeç
        }
        return true
    }

    private fun startDownload(
        url: String,
        userAgent: String?,
        contentDisposition: String?,
        mimeType: String?
    ) {
        val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
        if (!prefs.downloadAsk) {
            performDownload(url, userAgent, mimeType, fileName, prefs.downloadFolder)
            return
        }
        val names = Prefs.DOWNLOAD_FOLDERS.map { it.first }.toTypedArray()
        var selected = prefs.downloadFolder
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.download_title, fileName))
            .setSingleChoiceItems(names, selected) { _, which -> selected = which }
            .setPositiveButton(R.string.download_button) { _, _ ->
                performDownload(url, userAgent, mimeType, fileName, selected)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun performDownload(
        url: String,
        userAgent: String?,
        mimeType: String?,
        fileName: String,
        folderIndex: Int
    ) {
        try {
            val folder = Prefs.DOWNLOAD_FOLDERS[folderIndex.coerceIn(0, Prefs.DOWNLOAD_FOLDERS.size - 1)]
            val request = DownloadManager.Request(Uri.parse(url))
            if (mimeType != null) request.setMimeType(mimeType)
            if (userAgent != null) request.addRequestHeader("User-Agent", userAgent)
            val cookies = CookieManager.getInstance().getCookie(url)
            if (cookies != null) request.addRequestHeader("Cookie", cookies)
            request.setTitle(fileName)
            request.setNotificationVisibility(
                DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
            )
            request.setDestinationInExternalPublicDir(folder.second, "Gokboru/" + fileName)
            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            Toast.makeText(
                this,
                getString(R.string.download_started_to, fileName, folder.first),
                Toast.LENGTH_SHORT
            ).show()
        } catch (e: Exception) {
            Toast.makeText(this, R.string.download_failed, Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------------------------------
    // Gece modu, okuma modu, sayfada bul, yazı boyutu, uzun basma menüsü
    // ---------------------------------------------------------------------------------------

    private fun applyViewPrefs(webView: WebView) {
        webView.settings.textZoom = prefs.textZoom
        webView.settings.blockNetworkImage = prefs.blockImages
    }

    private fun applyNight(tab: BrowserTab) {
        if (tab.url.startsWith(NEWTAB_URL)) return
        tab.webView.evaluateJavascript(
            if (prefs.nightMode) PageScripts.NIGHT_ON else PageScripts.NIGHT_OFF,
            null
        )
    }

    private fun injectPageScripts(tab: BrowserTab) {
        if (tab.url.startsWith(NEWTAB_URL)) return
        applyNight(tab)
        if (prefs.adBlock) {
            tab.webView.evaluateJavascript(PageScripts.HIDE_ADS, null)
            val host = Uri.parse(tab.url).host.orEmpty()
            if (host.endsWith("youtube.com")) {
                tab.webView.evaluateJavascript(PageScripts.YOUTUBE_SKIP, null)
            }
        }
    }

    private fun startReaderMode() {
        val webView = current?.webView ?: return
        webView.evaluateJavascript(PageScripts.READER) { result ->
            if (result == null || result.contains("none")) {
                Toast.makeText(this, R.string.reader_unavailable, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showTextSizeDialog() {
        val sizes = Prefs.TEXT_SIZES
        val names = sizes.map { "$it%" }.toTypedArray()
        val checked = sizes.indexOf(prefs.textZoom).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle(R.string.menu_text_size)
            .setSingleChoiceItems(names, checked) { dialog, which ->
                prefs.textZoom = sizes[which]
                for (tab in tabs) applyViewPrefs(tab.webView)
                dialog.dismiss()
            }
            .show()
    }

    private fun showFind() {
        val webView = current?.webView ?: return
        val dialog = BottomSheetDialog(this)
        val sheet = layoutInflater.inflate(R.layout.sheet_find, null)
        val input = sheet.findViewById<EditText>(R.id.findInput)
        val count = sheet.findViewById<TextView>(R.id.findCount)

        webView.setFindListener { active, total, _ ->
            count.text = if (total == 0) "0/0" else "${active + 1}/$total"
        }
        input.doAfterTextChanged { text ->
            val query = text?.toString().orEmpty()
            if (query.isEmpty()) {
                webView.clearMatches()
                count.text = ""
            } else {
                webView.findAllAsync(query)
            }
        }
        sheet.findViewById<View>(R.id.findPrev).setOnClickListener { webView.findNext(false) }
        sheet.findViewById<View>(R.id.findNext).setOnClickListener { webView.findNext(true) }
        sheet.findViewById<View>(R.id.findClose).setOnClickListener { dialog.dismiss() }
        dialog.setOnDismissListener {
            webView.clearMatches()
            webView.setFindListener(null)
        }

        dialog.setContentView(sheet)
        dialog.window?.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        dialog.show()
        input.requestFocus()
    }

    private fun showLinkMenu(tab: BrowserTab, type: Int, target: String) {
        val isImage = type == WebView.HitTestResult.IMAGE_TYPE ||
            type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()

        labels.add(getString(R.string.ctx_open_new_tab))
        actions.add { newTab(target, tab.isPrivate) }
        labels.add(getString(R.string.ctx_copy_link))
        actions.add { copyText(target) }
        if (isImage) {
            labels.add(getString(R.string.ctx_save_image))
            actions.add {
                performDownload(
                    target, null, null,
                    URLUtil.guessFileName(target, null, null), prefs.downloadFolder
                )
            }
        }
        labels.add(getString(R.string.menu_share))
        actions.add { shareText(target) }

        AlertDialog.Builder(this)
            .setTitle(target)
            .setItems(labels.toTypedArray()) { _, which -> actions[which]() }
            .show()
    }

    private fun copyText(text: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("url", text))
        Toast.makeText(this, R.string.link_copied, Toast.LENGTH_SHORT).show()
    }

    private fun shareText(text: String) {
        val send = Intent(Intent.ACTION_SEND)
        send.type = "text/plain"
        send.putExtra(Intent.EXTRA_TEXT, text)
        startActivity(Intent.createChooser(send, getString(R.string.share_via)))
    }

    // ---------------------------------------------------------------------------------------
    // Geri tuşu, klavye, tam ekran
    // ---------------------------------------------------------------------------------------

    private fun handleBack() {
        if (immersive) {
            toggleImmersive()
            return
        }
        if (customView != null) {
            exitFullscreen()
            return
        }
        val tab = current
        if (tab != null && tab.webView.canGoBack()) {
            tab.webView.goBack()
            return
        }
        if (tab != null && tabs.size > 1) {
            closeTab(tab)
            return
        }
        val now = System.currentTimeMillis()
        if (now - lastBackPress < 2000) {
            finish()
        } else {
            lastBackPress = now
            Toast.makeText(this, R.string.press_back_again, Toast.LENGTH_SHORT).show()
        }
    }

    private fun focusAddress() {
        addressBar.requestFocus()
        val manager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        manager.showSoftInput(addressBar, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideKeyboard(view: View) {
        val manager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        manager.hideSoftInputFromWindow(view.windowToken, 0)
    }

    private fun exitFullscreen() {
        val view = customView ?: return
        val callback = customViewCallback
        customView = null
        customViewCallback = null
        fullscreenContainer.removeView(view)
        fullscreenContainer.visibility = View.GONE
        setSystemBarsVisible(true)
        callback?.onCustomViewHidden()
    }

    private fun setSystemBarsVisible(visible: Boolean) {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (visible) {
            controller.show(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        }
    }
}
