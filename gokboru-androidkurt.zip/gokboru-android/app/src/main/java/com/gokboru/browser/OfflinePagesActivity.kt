package com.gokboru.browser

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.text.DateFormat
import java.util.Date

/** Çevrimdışı kaydedilen sayfaların listesi. */
class OfflinePagesActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var items: LinearLayout
    private lateinit var empty: TextView
    private lateinit var subtitle: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        prefs = Prefs(this)
        items = findViewById(R.id.listItems)
        empty = findViewById(R.id.listEmpty)
        subtitle = findViewById(R.id.listSubtitle)
        findViewById<View>(R.id.listChipsScroll).visibility = View.GONE
        findViewById<TextView>(R.id.listHeading).setText(R.string.offline_title)
        findViewById<ImageButton>(R.id.listBack).setOnClickListener { finish() }
        empty.setText(R.string.offline_empty)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        // Dosyası silinmiş kayıtları listeden temizle
        for (entry in prefs.offlinePages()) {
            if (!File(entry.url).exists()) prefs.removeOffline(entry.url)
        }
        val pages = prefs.offlinePages()
        subtitle.text = getString(R.string.offline_summary, pages.size)
        empty.visibility = if (pages.isEmpty()) View.VISIBLE else View.GONE
        items.removeAllViews()

        for (page in pages) {
            val row = layoutInflater.inflate(R.layout.item_download, items, false)
            row.findViewById<TextView>(R.id.dlTitle).text = page.title
            row.findViewById<ImageView>(R.id.dlIcon).setImageResource(R.drawable.ic_offline)
            val file = File(page.url)
            val date = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(file.lastModified()))
            row.findViewById<TextView>(R.id.dlSub).text =
                Helpers.formatSize(this, file.length()) + " · " + date

            row.setOnClickListener { openPage(page.url) }
            row.findViewById<ImageButton>(R.id.dlMore).setOnClickListener { anchor ->
                val popup = PopupMenu(this, anchor)
                popup.menu.add(0, 1, 0, getString(R.string.dl_open))
                popup.menu.add(0, 2, 1, getString(R.string.dl_delete))
                popup.setOnMenuItemClickListener { menuItem ->
                    if (menuItem.itemId == 1) {
                        openPage(page.url)
                    } else {
                        File(page.url).delete()
                        prefs.removeOffline(page.url)
                        refresh()
                    }
                    true
                }
                popup.show()
            }
            items.addView(row)
        }
    }

    private fun openPage(path: String) {
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra("open_url", "file://$path")
        startActivity(intent)
        finish()
    }
}
