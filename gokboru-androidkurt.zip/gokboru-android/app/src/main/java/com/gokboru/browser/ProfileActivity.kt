package com.gokboru.browser

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** Opera / Quark tarzı profil ekranı: ad, e-posta, sayaçlar ve kısayollar. */
class ProfileActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var nameView: TextView
    private lateinit var emailView: TextView
    private lateinit var statsRow: LinearLayout
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        prefs = Prefs(this)
        nameView = findViewById(R.id.profileName)
        emailView = findViewById(R.id.profileEmail)
        statsRow = findViewById(R.id.profileStats)
        list = findViewById(R.id.profileList)
        findViewById<ImageButton>(R.id.profileBack).setOnClickListener { finish() }
        findViewById<View>(R.id.profileEdit).setOnClickListener { showEdit() }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val name = prefs.profileName
        nameView.text = if (name.isBlank()) getString(R.string.profile_guest) else name
        val email = prefs.profileEmail
        emailView.text = if (email.isBlank()) getString(R.string.profile_add_email) else email

        statsRow.removeAllViews()
        addStat(prefs.favorites().size.toString(), R.string.stat_favorites)
        addStat(prefs.history().size.toString(), R.string.stat_history)
        addStat(downloadCount().toString(), R.string.stat_downloads)
        addStat(Helpers.formatSize(this, Helpers.cacheSize(this)), R.string.stat_cache)
        buildList()
    }

    private fun addStat(value: String, label: Int) {
        val tile = layoutInflater.inflate(R.layout.item_stat, statsRow as ViewGroup, false)
        tile.findViewById<TextView>(R.id.statValue).text = value
        tile.findViewById<TextView>(R.id.statLabel).setText(label)
        statsRow.addView(tile)
    }

    private fun downloadCount(): Int {
        return try {
            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val cursor = manager.query(DownloadManager.Query())
            cursor?.use { it.count } ?: 0
        } catch (e: Exception) {
            0
        }
    }

    private fun buildList() {
        list.removeAllViews()

        Helpers.addRow(this, list, R.drawable.ic_download, getString(R.string.dl_title),
            getString(R.string.setting_downloads_sub), null) {
            startActivity(Intent(this, DownloadsActivity::class.java))
        }

        Helpers.addRow(this, list, R.drawable.ic_offline, getString(R.string.offline_title),
            getString(R.string.offline_sub), null) {
            startActivity(Intent(this, OfflinePagesActivity::class.java))
        }

        val focusSub = if (prefs.focusActive()) {
            getString(R.string.focus_sub_on, prefs.focusMinutesLeft())
        } else {
            getString(R.string.focus_sub_off)
        }
        Helpers.addRow(this, list, R.drawable.ic_timer, getString(R.string.focus_title), focusSub, null) {
            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("action", "focus")
            startActivity(intent)
        }

        Helpers.addRow(this, list, R.drawable.ic_moon, getString(R.string.setting_night),
            getString(R.string.setting_night_sub), prefs.nightMode) { checked ->
            prefs.nightMode = checked
        }

        Helpers.addRow(this, list, R.drawable.ic_trash, getString(R.string.cache_clear),
            Helpers.formatSize(this, Helpers.cacheSize(this)), null) {
            Helpers.clearCache(this)
            Toast.makeText(this, R.string.cache_cleared, Toast.LENGTH_SHORT).show()
            refresh()
        }

        Helpers.addRow(this, list, R.drawable.ic_settings, getString(R.string.menu_settings),
            null, null) {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        Helpers.addRow(this, list, R.drawable.ic_mail, getString(R.string.feedback_title),
            getString(R.string.app_email), null) {
            Helpers.sendFeedback(this)
        }

        Helpers.addRow(this, list, R.drawable.ic_star, getString(R.string.about_title),
            getString(R.string.setting_about_sub), null) {
            Helpers.showAbout(this)
        }
    }

    private fun showEdit() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(Helpers.dp(this, 22), Helpers.dp(this, 8), Helpers.dp(this, 22), 0)

        val nameInput = EditText(this)
        nameInput.hint = getString(R.string.profile_name_hint)
        nameInput.setSingleLine()
        nameInput.setText(prefs.profileName)

        val emailInput = EditText(this)
        emailInput.hint = getString(R.string.profile_email_hint)
        emailInput.setSingleLine()
        emailInput.inputType = android.text.InputType.TYPE_CLASS_TEXT or
            android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        emailInput.setText(prefs.profileEmail)

        box.addView(nameInput)
        box.addView(emailInput)

        AlertDialog.Builder(this)
            .setTitle(R.string.profile_title)
            .setView(box)
            .setPositiveButton(R.string.ok) { _, _ ->
                val email = emailInput.text.toString().trim()
                if (email.isNotEmpty() && !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    Toast.makeText(this, R.string.profile_email_invalid, Toast.LENGTH_SHORT).show()
                } else {
                    prefs.profileName = nameInput.text.toString().trim()
                    prefs.profileEmail = email
                    Toast.makeText(this, R.string.profile_saved, Toast.LENGTH_SHORT).show()
                    refresh()
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
