package com.gokboru.browser

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.format.Formatter
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SwitchCompat
import java.io.File

/** Birden fazla ekranın kullandığı küçük yardımcılar. */
object Helpers {

    fun dp(context: Context, value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()

    fun versionName(context: Context): String {
        return try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    fun formatSize(context: Context, bytes: Long): String =
        Formatter.formatFileSize(context, bytes)

    fun sendFeedback(context: Context) {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
        intent.putExtra(Intent.EXTRA_EMAIL, arrayOf(context.getString(R.string.app_email)))
        intent.putExtra(Intent.EXTRA_SUBJECT, context.getString(R.string.feedback_subject))
        try {
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, R.string.feedback_no_mail, Toast.LENGTH_SHORT).show()
        }
    }

    fun showAbout(activity: Activity) {
        AlertDialog.Builder(activity)
            .setTitle(R.string.about_title)
            .setMessage(
                activity.getString(
                    R.string.about_text,
                    versionName(activity),
                    activity.getString(R.string.app_email)
                )
            )
            .setPositiveButton(R.string.about_send) { _, _ -> sendFeedback(activity) }
            .setNegativeButton(R.string.ok, null)
            .show()
    }

    fun dirSize(file: File): Long {
        if (file.isFile) return file.length()
        var total = 0L
        val children = file.listFiles() ?: return 0L
        for (child in children) total += dirSize(child)
        return total
    }

    fun cacheSize(context: Context): Long = dirSize(context.cacheDir)

    fun clearCache(context: Context) {
        try {
            WebView(context).clearCache(true)
        } catch (e: Exception) {
            // WebView oluşturulamazsa yalnızca dosya önbelleği silinir
        }
        val children = context.cacheDir.listFiles() ?: return
        for (child in children) child.deleteRecursively()
    }

    /** Ayar satırı ekler. switchState null ise anahtarsızdır. */
    fun addRow(
        activity: Activity,
        container: LinearLayout,
        icon: Int,
        title: String,
        sub: String?,
        switchState: Boolean?,
        action: (Boolean) -> Unit
    ) {
        val row = activity.layoutInflater.inflate(R.layout.item_row, container as ViewGroup, false)
        row.findViewById<ImageView>(R.id.rowIcon).setImageResource(icon)
        row.findViewById<TextView>(R.id.rowTitle).text = title
        val subView = row.findViewById<TextView>(R.id.rowSub)
        if (!sub.isNullOrBlank()) {
            subView.text = sub
            subView.visibility = View.VISIBLE
        }
        val switch = row.findViewById<SwitchCompat>(R.id.rowSwitch)
        if (switchState != null) {
            switch.visibility = View.VISIBLE
            switch.isChecked = switchState
            row.setOnClickListener {
                switch.isChecked = !switch.isChecked
                action(switch.isChecked)
            }
        } else {
            row.setOnClickListener { action(false) }
        }
        container.addView(row)
    }
}
