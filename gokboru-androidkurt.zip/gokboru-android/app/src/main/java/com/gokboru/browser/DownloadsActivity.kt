package com.gokboru.browser

import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.DateFormat
import java.util.Date

/** Uygulamanın kendi İndirilenler ekranı: filtre, ilerleme, aç, paylaş, sil. */
class DownloadsActivity : AppCompatActivity() {

    private class Item(
        val id: Long,
        val title: String,
        val mime: String,
        val total: Long,
        val done: Long,
        val status: Int,
        val time: Long
    )

    private lateinit var items: LinearLayout
    private lateinit var empty: TextView
    private lateinit var subtitle: TextView
    private lateinit var chipRow: LinearLayout
    private lateinit var manager: DownloadManager

    private var filter = 0
    private var lastSignature = ""
    private val handler = Handler(Looper.getMainLooper())
    private val poll = object : Runnable {
        override fun run() {
            refresh(false)
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        items = findViewById(R.id.listItems)
        empty = findViewById(R.id.listEmpty)
        subtitle = findViewById(R.id.listSubtitle)
        chipRow = findViewById(R.id.listChips)
        findViewById<TextView>(R.id.listHeading).setText(R.string.dl_title)
        findViewById<ImageButton>(R.id.listBack).setOnClickListener { finish() }
        empty.setText(R.string.dl_empty)
    }

    override fun onResume() {
        super.onResume()
        refresh(true)
        handler.postDelayed(poll, 1000L)
    }

    override fun onPause() {
        handler.removeCallbacks(poll)
        super.onPause()
    }

    private fun load(): List<Item> {
        val result = ArrayList<Item>()
        try {
            val cursor = manager.query(DownloadManager.Query())
            cursor?.use {
                val iId = it.getColumnIndexOrThrow(DownloadManager.COLUMN_ID)
                val iTitle = it.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)
                val iMime = it.getColumnIndexOrThrow(DownloadManager.COLUMN_MEDIA_TYPE)
                val iTotal = it.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                val iDone = it.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                val iStatus = it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)
                val iTime = it.getColumnIndexOrThrow(DownloadManager.COLUMN_LAST_MODIFIED_TIMESTAMP)
                while (it.moveToNext()) {
                    result.add(
                        Item(
                            it.getLong(iId),
                            it.getString(iTitle) ?: "",
                            it.getString(iMime) ?: "",
                            it.getLong(iTotal),
                            it.getLong(iDone),
                            it.getInt(iStatus),
                            it.getLong(iTime)
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // İndirme listesi okunamazsa boş liste gösterilir
        }
        result.sortByDescending { it.time }
        return result
    }

    /** 1 resim, 2 video, 3 belge, 4 diğer */
    private fun category(item: Item): Int {
        val m = item.mime.lowercase()
        return when {
            m.startsWith("image/") -> 1
            m.startsWith("video/") -> 2
            m.startsWith("text/") || m.contains("pdf") || m.contains("word") ||
                m.contains("excel") || m.contains("powerpoint") || m.contains("officedocument") -> 3
            else -> 4
        }
    }

    private fun refresh(force: Boolean) {
        val all = load()
        val signature = all.joinToString("|") { "${it.id}:${it.status}:${it.done}" } + "#" + filter
        if (!force && signature == lastSignature) return
        lastSignature = signature

        buildChips()

        val finished = all.filter { it.status == DownloadManager.STATUS_SUCCESSFUL }
        subtitle.text = getString(
            R.string.dl_summary,
            finished.size,
            Helpers.formatSize(this, finished.sumOf { it.total.coerceAtLeast(0L) })
        )

        val shown = if (filter == 0) all else all.filter { category(it) == filter }
        items.removeAllViews()
        empty.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
        for (item in shown) addItem(item)
    }

    private fun buildChips() {
        chipRow.removeAllViews()
        val labels = intArrayOf(
            R.string.dl_all, R.string.dl_images, R.string.dl_videos, R.string.dl_docs, R.string.dl_other
        )
        for (index in labels.indices) {
            val chip = TextView(this)
            chip.setText(labels[index])
            chip.textSize = 14f
            chip.setPadding(
                Helpers.dp(this, 18), Helpers.dp(this, 8), Helpers.dp(this, 18), Helpers.dp(this, 8)
            )
            val selected = index == filter
            chip.setBackgroundResource(if (selected) R.drawable.bg_pill_selected else R.drawable.bg_pill)
            chip.setTextColor(getColor(if (selected) R.color.night else R.color.text))
            val params = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            params.marginEnd = Helpers.dp(this, 8)
            chip.setOnClickListener {
                filter = index
                refresh(true)
            }
            chipRow.addView(chip, params)
        }
    }

    private fun addItem(item: Item) {
        val row = layoutInflater.inflate(R.layout.item_download, items, false)
        row.findViewById<TextView>(R.id.dlTitle).text = item.title.ifBlank { "?" }

        val icon = row.findViewById<ImageView>(R.id.dlIcon)
        icon.setImageResource(
            when (category(item)) {
                1 -> R.drawable.ic_image
                2 -> R.drawable.ic_play
                3 -> R.drawable.ic_file
                else -> R.drawable.ic_download
            }
        )

        val sub = row.findViewById<TextView>(R.id.dlSub)
        val progress = row.findViewById<ProgressBar>(R.id.dlProgress)
        val finished = item.status == DownloadManager.STATUS_SUCCESSFUL
        when (item.status) {
            DownloadManager.STATUS_SUCCESSFUL -> {
                val date = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(item.time))
                sub.text = Helpers.formatSize(this, item.total.coerceAtLeast(0L)) + " · " + date
            }
            DownloadManager.STATUS_FAILED -> sub.setText(R.string.dl_failed)
            DownloadManager.STATUS_PAUSED -> sub.setText(R.string.dl_paused)
            DownloadManager.STATUS_PENDING -> sub.setText(R.string.dl_waiting)
            else -> {
                sub.text = getString(
                    R.string.dl_progress,
                    Helpers.formatSize(this, item.done),
                    if (item.total > 0) Helpers.formatSize(this, item.total) else "?"
                )
                if (item.total > 0) {
                    progress.visibility = View.VISIBLE
                    progress.progress = ((item.done * 100L) / item.total).toInt()
                }
            }
        }

        if (finished) row.setOnClickListener { openItem(item) }
        row.findViewById<ImageButton>(R.id.dlMore).setOnClickListener { anchor ->
            val popup = PopupMenu(this, anchor)
            if (finished) {
                popup.menu.add(0, 1, 0, getString(R.string.dl_open))
                popup.menu.add(0, 2, 1, getString(R.string.dl_share))
            }
            popup.menu.add(0, 3, 2, getString(R.string.dl_delete))
            popup.setOnMenuItemClickListener { menuItem ->
                when (menuItem.itemId) {
                    1 -> openItem(item)
                    2 -> shareItem(item)
                    3 -> {
                        manager.remove(item.id)
                        refresh(true)
                    }
                }
                true
            }
            popup.show()
        }
        items.addView(row)
    }

    private fun openItem(item: Item) {
        val uri = manager.getUriForDownloadedFile(item.id)
        if (uri == null) {
            Toast.makeText(this, R.string.dl_no_app, Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(Intent.ACTION_VIEW)
        intent.setDataAndType(uri, item.mime.ifEmpty { "*/*" })
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.dl_no_app, Toast.LENGTH_SHORT).show()
        }
    }

    private fun shareItem(item: Item) {
        val uri = manager.getUriForDownloadedFile(item.id) ?: return
        val intent = Intent(Intent.ACTION_SEND)
        intent.type = item.mime.ifEmpty { "*/*" }
        intent.putExtra(Intent.EXTRA_STREAM, uri)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            startActivity(Intent.createChooser(intent, null))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.dl_no_app, Toast.LENGTH_SHORT).show()
        }
    }
}
