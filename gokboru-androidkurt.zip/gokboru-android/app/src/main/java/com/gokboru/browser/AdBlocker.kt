package com.gokboru.browser

import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.util.concurrent.atomic.AtomicInteger

/**
 * Alan adı ve adres kalıbı tabanlı reklam/izleyici engelleyici.
 * Not: uBlock gibi tam bir filtre motoru değildir; yaygın reklam ağlarını engeller,
 * boş kalan reklam kutularını gizler. Sitelerin kendi içinden gelen reklamlarını
 * (ör. YouTube) yalnızca kısmen geçebilir.
 */
object AdBlocker {

    /** Uygulama açıldığından beri engellenen istek sayısı. */
    val blocked = AtomicInteger(0)

    private val hosts = hashSetOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "pagead2.googlesyndication.com", "google-analytics.com",
        "googletagmanager.com", "googletagservices.com", "adnxs.com", "adsrvr.org",
        "advertising.com", "taboola.com", "outbrain.com", "criteo.com", "criteo.net",
        "pubmatic.com", "rubiconproject.com", "openx.net", "casalemedia.com",
        "smartadserver.com", "moatads.com", "scorecardresearch.com", "quantserve.com",
        "amazon-adsystem.com", "adform.net", "yieldmo.com", "mgid.com", "revcontent.com",
        "popads.net", "propellerads.com", "adsterra.com", "exoclick.com", "juicyads.com",
        "hotjar.com", "mixpanel.com", "facebook.net", "ads.yahoo.com", "adcolony.com",
        "applovin.com", "unity3d.com", "inmobi.com", "mopub.com", "yandexadexchange.net",
        "an.yandex.ru", "adriver.ru", "teads.tv", "zedo.com", "adtech.com", "bidswitch.net",
        "adsafeprotected.com", "serving-sys.com", "adition.com", "360yield.com", "tapad.com",
        "bluekai.com", "krxd.net", "demdex.net", "everesttech.net", "agkn.com", "media.net",
        "sharethrough.com", "triplelift.com", "33across.com", "lijit.com", "sovrn.com",
        "spotxchange.com", "adskeeper.com", "clickadu.com", "hilltopads.net", "monetag.com",
        "onclickads.net", "a-ads.com", "bidvertiser.com", "infolinks.com", "zemanta.com",
        "admixer.net", "smaato.net", "chartboost.com", "vungle.com", "ironsrc.com",
        "supersonicads.com", "startapp.com", "tapjoy.com", "fyber.com", "adfox.ru",
        "mc.yandex.ru", "analytics.yahoo.com", "stats.g.doubleclick.net", "pixel.facebook.com",
        "ads.twitter.com", "static.ads-twitter.com", "ads.linkedin.com", "px.ads.linkedin.com",
        "analytics.tiktok.com", "ads.tiktok.com", "adsymptotic.com", "contextweb.com",
        "gumgum.com", "indexww.com", "richaudience.com", "improvedigital.com", "adspirit.de",
        "yadro.ru", "top-fwz1.mail.ru", "counter.yadro.ru", "popcash.net", "adcash.com",
        "adsco.re", "ad.gt", "adlightning.com", "adgrx.com", "adotmob.com", "adhigh.net",
        "pushwoosh.com", "onesignal.com", "cdn.mookie1.com", "yieldlab.net", "ligatus.com",
        "plista.com", "nativeads.com", "trafficjunky.net", "trafficfactory.biz", "rtbhouse.com",
        "adtelligent.com", "ad-score.com", "pagead.l.google.com", "partner.googleadservices.com",
        "app-measurement.com", "crashlytics.com", "branch.io", "adjust.com", "appsflyer.com",
        "flurry.com", "segment.io", "optimizely.com", "newrelic.com", "clarity.ms"
    )

    private val urlParts = listOf(
        "/pagead/", "/adserver", "/ads/js", "/adframe", "/adsbygoogle", "googleads.",
        "/banner_ads", "/ad_banner", "/adview", "/ad-frame", "/ads.js", "/adserve", "/popunder", "/pop-under", "prebid", "/adsense/", "/doubleclick/", "ad.doubleclick"
    )

    fun isBlocked(host: String?): Boolean {
        if (host.isNullOrEmpty()) return false
        var h = host.lowercase()
        while (true) {
            if (h in hosts) return true
            val dot = h.indexOf('.')
            if (dot < 0) return false
            h = h.substring(dot + 1)
            if (!h.contains('.')) return false
        }
    }

    /** Alt kaynak isteğinin engellenip engellenmeyeceğine karar verir ve sayacı artırır. */
    fun shouldBlock(url: String?, host: String?): Boolean {
        val hit = isBlocked(host) || matchesPattern(url)
        if (hit) blocked.incrementAndGet()
        return hit
    }

    private fun matchesPattern(url: String?): Boolean {
        if (url.isNullOrEmpty()) return false
        val lower = url.lowercase()
        for (part in urlParts) {
            if (lower.contains(part)) return true
        }
        return false
    }

    fun emptyResponse(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
}
