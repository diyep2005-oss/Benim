package com.gokboru.browser

/** Sayfaya enjekte edilen küçük JavaScript parçaları (gece modu, reklam gizleme, okuma modu). */
object PageScripts {

    /** Gece modu: sayfayı ters çevirir, resim ve videoları tekrar çevirerek normal bırakır. */
    val NIGHT_ON = """
        (function(){
          var s=document.getElementById('gk-night');
          if(!s){s=document.createElement('style');s.id='gk-night';(document.head||document.documentElement).appendChild(s);}
          s.textContent='html{background:#fff!important;filter:invert(1) hue-rotate(180deg)!important}img,video,canvas,picture{filter:invert(1) hue-rotate(180deg)!important}';
        })();
    """.trimIndent()

    val NIGHT_OFF = """
        (function(){
          var s=document.getElementById('gk-night');
          if(s){s.parentNode.removeChild(s);}
        })();
    """.trimIndent()

    /** Sayfadaki boş kalan reklam kutularını gizler. */
    val HIDE_ADS = """
        (function(){
          if(document.getElementById('gk-adhide'))return;
          var s=document.createElement('style');s.id='gk-adhide';
          s.textContent='ins.adsbygoogle,.adsbygoogle,[id^="google_ads"],[id^="div-gpt-ad"],[id^="ad-slot"],iframe[src*="doubleclick"],iframe[src*="googlesyndication"],iframe[src*="adservice"],.ad-banner,.ad-container,.ad-wrapper,.advert,.advertisement,.ads-banner,.sponsored-ad,#ad-banner,#ad_banner,a[href*="/adclick"]{display:none!important}';
          (document.head||document.documentElement).appendChild(s);
        })();
    """.trimIndent()

    /** YouTube video reklamlarını geçmeye çalışır (YouTube değişirse çalışmayabilir). */
    val YOUTUBE_SKIP = """
        (function(){
          if(window.__gkyt)return; window.__gkyt=true;
          setInterval(function(){
            var p=document.querySelector('.html5-video-player.ad-showing');
            var v=document.querySelector('video');
            if(p&&v&&isFinite(v.duration)&&v.duration>0){v.currentTime=v.duration;}
            var b=document.querySelector('.ytp-ad-skip-button,.ytp-skip-ad-button,.ytp-ad-skip-button-modern');
            if(b){b.click();}
            var o=document.querySelector('.ytp-ad-overlay-close-button');
            if(o){o.click();}
          },500);
        })();
    """.trimIndent()

    /** Okuma modu: makaleyi sade, koyu temalı bir sayfaya dönüştürür. Başarılıysa "ok", değilse "none" döner. */
    val READER = """
        (function(){
          function esc(t){return t.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
          var root=document.querySelector('article')||document.querySelector('main')||document.querySelector('[role=main]');
          if(!root){
            var best=null,max=0;
            var boxes=document.querySelectorAll('div,section');
            for(var i=0;i<boxes.length;i++){
              var ps=boxes[i].querySelectorAll(':scope > p');var n=0;
              for(var j=0;j<ps.length;j++){n+=ps[j].innerText.length;}
              if(n>max){max=n;best=boxes[i];}
            }
            root=best;
          }
          if(!root){return 'none';}
          var parts=[];
          var els=root.querySelectorAll('h1,h2,h3,p,li,blockquote,img');
          for(var k=0;k<els.length;k++){
            var e=els[k];var tag=e.tagName.toLowerCase();
            if(tag==='img'){
              if((e.naturalWidth||e.width)>200&&e.currentSrc){parts.push('<img src="'+e.currentSrc+'">');}
            }else{
              var t=(e.innerText||'').trim();
              if(t.length>0){
                if(tag==='li'){parts.push('<p>&bull; '+esc(t)+'</p>');}
                else{parts.push('<'+tag+'>'+esc(t)+'</'+tag+'>');}
              }
            }
          }
          if(parts.join('').length<200){return 'none';}
          var title=esc(document.title||'');
          var old=document.querySelectorAll('link[rel=stylesheet],style');
          for(var m=0;m<old.length;m++){old[m].parentNode.removeChild(old[m]);}
          var css=document.createElement('style');
          css.textContent='html,body{background:#040E16!important;color:#F3E7C9!important;filter:none!important}body{font:19px/1.75 Georgia,serif;max-width:720px;margin:0 auto;padding:18px}h1,h2,h3{color:#F5B942;line-height:1.3}img{max-width:100%;height:auto;border-radius:10px;margin:12px 0}blockquote{border-left:3px solid #F5B942;margin:12px 0;padding-left:14px;color:#B7A77F}';
          document.head.appendChild(css);
          document.body.className='';document.body.removeAttribute('style');
          document.body.innerHTML='<h1>'+title+'</h1>'+parts.join('');
          window.scrollTo(0,0);
          return 'ok';
        })();
    """.trimIndent()
}
